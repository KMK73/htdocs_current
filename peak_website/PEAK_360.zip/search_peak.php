<DOCTYPE HTML>
	<head>
		<title>Search Peak 360</title>
	</head>

<body>
	<h1>Search Peak Database</h1>

	<form action ="search_peak.php" method="GET">
	
	<h3>Date of WOD</h3>
	<input type ="date" name="wod_date"/>

	<p><input type= "submit" value = "Search"/></p>

	</form>

	<?php
		error_reporting(E_ALL);
		
		if ($mysqli->connect_errno) {
	    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
		}



		$sql_link = new mysqli("localhost", "administrator", "admin", "peak_360");

		$query = "";

		if($_GET['wod_date']) {


			// $workout_name = mysqli_escape_string($sql_link, $_GET['workout_name']);
			// $type = mysqli_escape_string($sql_link, $_GET['type']);
			// echo "$type";
			
			// $description = mysqli_escape_string($sql_link, $_GET['description']);
			// //converting the date to right format
			$wod_date = mysqli_escape_string ($sql_link, $_GET['wod_date']);
			$integer_date = strtotime($wod_date); //integer date format
			$formatted_date = date("Y-m-d", $integer_date);


			$query =sprintf("SELECT workout_name, wod_type, description FROM workouts WHERE wod_date = '%s'" , $formatted_date);
			// echo $query;
		} else {

			$query = "SELECT workout_name FROM workouts";

		}

			$result = mysqli_query($sql_link, $query);
			$json = array();
				
			foreach($result as $row) {
				$json[] = array("workout_name" => $row['workout_name'], "wod_type" => $row['wod_type'], "description" => $row['description']);
			}
			echo json_encode($json);
	?>


</body>
</html>